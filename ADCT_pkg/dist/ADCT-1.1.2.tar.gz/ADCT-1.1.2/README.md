# ADCT

(A) (D)ata (C)lustering (T)ool

A python package able to perform and illustrate a few clustering methods.

Required Packages:
- numpy
- matplotlib
- random

To use package...

import ADCT

Future updates will include terminal/pipeline prompts
